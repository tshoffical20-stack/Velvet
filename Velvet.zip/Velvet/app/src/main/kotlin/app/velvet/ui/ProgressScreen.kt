package app.velvet.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.velvet.UiState
import app.velvet.domain.Achievement
import app.velvet.domain.AchievementCatalog
import app.velvet.domain.Metric

private fun metricLabel(m: Metric): String = when (m) {
    Metric.DIARY_ENTRIES -> "записей в дневнике"
    Metric.ACTIVE_DAYS -> "дней с приложением"
    Metric.MOOD_ENTRIES -> "отметок настроения"
    Metric.SELFCARE_ACTIONS -> "действий заботы о себе"
    Metric.ARTICLES_READ -> "прочитанных статей"
    Metric.QUIZZES_DONE -> "выполненных заданий"
    Metric.SECTIONS_VISITED -> "открытых разделов"
    Metric.REPORTS_VIEWED -> "просмотренных отчётов"
    Metric.GOALS_COMPLETED -> "выполненных целей"
    Metric.CYCLES_LOGGED -> "отмеченных циклов"
    Metric.DAYS_SINCE_JOIN -> "дней вместе"
    Metric.COLLECTION_ITEMS -> "предметов коллекции"
    Metric.CUSTOMIZATIONS -> "изменений оформления"
}

private sealed interface Row2 {
    data class Header(val title: String) : Row2
    data class Item(val a: Achievement) : Row2
}

@Composable
fun ProgressScreen(state: UiState) {
    val rows = AchievementCatalog.all.groupBy { it.category }.flatMap { (cat, list) ->
        listOf<Row2>(Row2.Header(cat.title)) + list.map { Row2.Item(it) }
    }
    val unlocked = AchievementCatalog.unlocked(state.stats).size

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("Прогресс", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 16.dp)) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Уровень ${state.level.level}", style = MaterialTheme.typography.titleLarge)
                    LinearProgressIndicator(progress = { state.level.fraction }, modifier = Modifier.fillMaxWidth())
                    Text("${state.level.xpIntoLevel} / ${state.level.xpForNextLevel} XP до следующего уровня. Всего ${state.totalXp} XP.")
                    Text("Достижений: $unlocked из ${AchievementCatalog.all.size}.")
                    Text(
                        "XP начисляется только за полезные действия и никогда не снимается. Пропуски дней ничего не отнимают. Часть счётчиков заработает вместе с модулями дневника, аналитики и обучения.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        items(rows) { row ->
            when (row) {
                is Row2.Header -> Text(row.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
                is Row2.Item -> {
                    val a = row.a
                    val done = a.isUnlocked(state.stats)
                    Column(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text((if (done) "✓ " else "") + a.title)
                            Text("${a.current(state.stats)} / ${a.threshold}", style = MaterialTheme.typography.bodySmall)
                        }
                        LinearProgressIndicator(
                            progress = { a.current(state.stats).toFloat() / a.threshold },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text(metricLabel(a.metric), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item { Text("", modifier = Modifier.padding(8.dp)) }
    }
}
