package app.velvet.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.velvet.UiState
import app.velvet.VelvetViewModel
import app.velvet.data.ThemeMode

@Composable
fun SettingsScreen(state: UiState, vm: VelvetViewModel) {
    var confirm by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineMedium)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Тема оформления", style = MaterialTheme.typography.titleMedium)
                listOf(
                    ThemeMode.SYSTEM to "Как в системе",
                    ThemeMode.LIGHT to "Светлая",
                    ThemeMode.DARK to "Тёмная",
                ).forEach { (mode, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.setTheme(mode) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = state.themeMode == mode, onClick = { vm.setTheme(mode) })
                        Text(label)
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Приватность", style = MaterialTheme.typography.titleMedium)
                Text("• Все данные хранятся только на этом устройстве.")
                Text("• У приложения нет доступа в интернет: оно технически не может ничего отправить.")
                Text("• Нет рекламы, аналитики и сторонних SDK.")
                Text("• Резервное копирование Android отключено, скриншоты и превью в списке приложений скрыты.")
                Text("• Данные зашифрованы (AES-256-GCM), ключ хранится в Android Keystore и не покидает устройство.")
                Text(
                    "PIN-код и биометрическая блокировка запланированы на следующий этап.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ваши данные", style = MaterialTheme.typography.titleMedium)
                Text("Отмечено циклов: ${state.starts.size}")
                Button(
                    onClick = { confirm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("Удалить все данные") }
            }
        }

        Text("Velvet 0.1.0. Не заменяет консультацию врача.", style = MaterialTheme.typography.bodySmall)
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Удалить все данные?") },
            text = { Text("Отметки, прогресс и настройки будут стёрты без возможности восстановления.") },
            confirmButton = { TextButton(onClick = { vm.clearAllData(); confirm = false }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } },
        )
    }
}
