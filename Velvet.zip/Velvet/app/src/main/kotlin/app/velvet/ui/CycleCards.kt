package app.velvet.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.velvet.R
import app.velvet.domain.cycle.Confidence
import app.velvet.domain.cycle.CyclePrediction
import app.velvet.domain.cycle.DateRange
import app.velvet.domain.cycle.DoctorFlag
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
internal fun PredictionCard(p: CyclePrediction) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.title_next_period), style = MaterialTheme.typography.titleMedium)
            Text(rangeText(p.nextStartRange), style = MaterialTheme.typography.headlineSmall)
            Text(stringResource(R.string.expected_format, formatDate(p.expectedNextStart)))

            Text(stringResource(R.string.title_ovulation), style = MaterialTheme.typography.titleSmall)
            Text(rangeText(p.likelyOvulationWindow))

            Text(stringResource(R.string.title_fertile), style = MaterialTheme.typography.titleSmall)
            Text(rangeText(p.fertileWindow))

            Text(
                stringResource(confidenceRes(p.confidence)),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
            if (p.cyclesUsed > 0) {
                Text(
                    stringResource(R.string.cycles_used_format, p.cyclesUsed, p.averageCycleLengthDays),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
internal fun DoctorFlagsCard(flags: Set<DoctorFlag>) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.flag_title), style = MaterialTheme.typography.titleMedium)
            flags.forEach { Text(stringResource(flagRes(it))) }
            Text(stringResource(R.string.flag_note), style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun confidenceRes(c: Confidence): Int = when (c) {
    Confidence.INSUFFICIENT_DATA -> R.string.confidence_insufficient
    Confidence.LOW -> R.string.confidence_low
    Confidence.MODERATE -> R.string.confidence_moderate
    Confidence.HIGH -> R.string.confidence_high
}

private fun flagRes(f: DoctorFlag): Int = when (f) {
    DoctorFlag.CYCLE_SHORTER_THAN_21 -> R.string.flag_short
    DoctorFlag.CYCLE_LONGER_THAN_35 -> R.string.flag_long
    DoctorFlag.PERIOD_LONGER_THAN_7_DAYS -> R.string.flag_period_long
    DoctorFlag.NO_PERIOD_FOR_90_DAYS -> R.string.flag_none_for_90
}

private val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)

internal fun formatDate(d: LocalDate): String = dateFormatter.format(d)

@Composable
private fun rangeText(r: DateRange): String =
    stringResource(R.string.range_format, formatDate(r.start), formatDate(r.end))
