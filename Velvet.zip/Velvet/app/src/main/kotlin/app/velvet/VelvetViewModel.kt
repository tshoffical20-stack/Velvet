package app.velvet

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import app.velvet.data.PeriodRepository
import app.velvet.data.SecureStore
import app.velvet.data.ThemeMode
import app.velvet.data.VelvetStore
import app.velvet.domain.LevelProgress
import app.velvet.domain.Leveling
import app.velvet.domain.Metric
import app.velvet.domain.cycle.CyclePrediction
import app.velvet.domain.cycle.CyclePredictor
import app.velvet.domain.cycle.DoctorFlag
import app.velvet.domain.cycle.HealthFlags
import app.velvet.domain.cycle.PeriodRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDate
import java.time.YearMonth

data class UiState(
    val today: LocalDate,
    val month: YearMonth,
    val selected: LocalDate,
    val starts: Set<LocalDate>,
    val prediction: CyclePrediction?,
    val flags: Set<DoctorFlag>,
    val totalXp: Long,
    val level: LevelProgress,
    val stats: Map<Metric, Int>,
    val themeMode: ThemeMode,
)

class VelvetViewModel(app: Application) : AndroidViewModel(app) {
    private val periods = PeriodRepository(SecureStore(app, "cycle.dat"))
    private val store = VelvetStore(app)
    private val predictor = CyclePredictor()
    private val _state: MutableStateFlow<UiState>
    val state: StateFlow<UiState> get() = _state

    init {
        store.markActive(LocalDate.now())
        _state = MutableStateFlow(build(YearMonth.now(), LocalDate.now()))
    }

    private fun build(month: YearMonth, selected: LocalDate): UiState {
        val today = LocalDate.now()
        val starts = periods.load().toSet()
        val xp = store.xpAwardedDates().size * XP_PER_PERIOD_LOG
        return UiState(
            today = today, month = month, selected = selected, starts = starts,
            prediction = predictor.predict(starts),
            flags = HealthFlags.evaluate(starts.map { PeriodRecord(it) }, today),
            totalXp = xp, level = Leveling.progress(xp),
            stats = store.stats(starts.size), themeMode = store.themeMode(),
        )
    }

    private fun refresh() { _state.value = build(_state.value.month, _state.value.selected) }

    fun select(date: LocalDate) { _state.value = _state.value.copy(selected = date) }
    fun shiftMonth(delta: Long) { _state.value = _state.value.copy(month = _state.value.month.plusMonths(delta)) }

    /** Отмечает или снимает отметку начала менструации. Будущие даты не принимаются. */
    fun togglePeriodStart(date: LocalDate) {
        if (date.isAfter(LocalDate.now())) return
        if (date in periods.load()) {
            periods.remove(date)
        } else {
            periods.add(date)
            if (date !in store.xpAwardedDates()) store.addXpAwardedDate(date)
        }
        refresh()
    }

    fun visitSection(name: String) {
        if (name !in store.visitedSections()) { store.markSectionVisited(name); refresh() }
    }

    fun setTheme(mode: ThemeMode) {
        if (mode == store.themeMode()) return
        store.saveThemeMode(mode)
        store.countCustomization()
        refresh()
    }

    fun clearAllData() {
        periods.clear()
        store.clearAll()
        store.markActive(LocalDate.now())
        _state.value = build(YearMonth.now(), LocalDate.now())
    }

    companion object { const val XP_PER_PERIOD_LOG = 20L }
}
