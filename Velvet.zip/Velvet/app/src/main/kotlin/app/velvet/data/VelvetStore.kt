package app.velvet.data

import android.content.Context
import app.velvet.domain.Metric
import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/**
 * Прогресс, настройки и счётчики. Хранится одним файлом, зашифрованным через [SecureStore]
 * (AES-256-GCM, ключ в Android Keystore). Формат: строки «ключ<TAB>значение».
 */
class VelvetStore(context: Context) {
    private val secure = SecureStore(context, "progress.dat")
    private val map: MutableMap<String, String> = load()

    private fun load(): MutableMap<String, String> {
        val result = mutableMapOf<String, String>()
        secure.read()?.lineSequence()?.forEach { line ->
            val i = line.indexOf('\t')
            if (i > 0) result[line.substring(0, i)] = line.substring(i + 1)
        }
        return result
    }

    private fun put(key: String, value: String) {
        map[key] = value
        secure.write(map.entries.joinToString("\n") { "${it.key}\t${it.value}" })
    }

    private fun readDates(key: String): Set<LocalDate> =
        map[key]?.split(',')?.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }?.toSet().orEmpty()

    private fun writeDates(key: String, dates: Set<LocalDate>) = put(key, dates.sorted().joinToString(","))

    /** Даты, за которые XP уже начислен. Удаление отметки XP не отнимает. */
    fun xpAwardedDates(): Set<LocalDate> = readDates("xp_awarded")
    fun addXpAwardedDate(date: LocalDate) = writeDates("xp_awarded", xpAwardedDates() + date)

    fun activeDays(): Set<LocalDate> = readDates("active_days")
    fun markActive(day: LocalDate) {
        if (day !in activeDays()) writeDates("active_days", activeDays() + day)
    }

    fun joinDate(): LocalDate {
        map["join_date"]?.let { s -> runCatching { LocalDate.parse(s) }.getOrNull()?.let { return it } }
        val today = LocalDate.now()
        put("join_date", today.toString())
        return today
    }

    fun visitedSections(): Set<String> = map["sections"]?.split(',')?.filter { it.isNotBlank() }?.toSet().orEmpty()
    fun markSectionVisited(name: String) = put("sections", (visitedSections() + name).sorted().joinToString(","))

    fun customizations(): Int = map["customizations"]?.toIntOrNull() ?: 0
    fun countCustomization() = put("customizations", (customizations() + 1).toString())

    fun themeMode(): ThemeMode = runCatching { ThemeMode.valueOf(map["theme"] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM)
    fun saveThemeMode(mode: ThemeMode) = put("theme", mode.name)

    fun stats(cyclesLogged: Int): Map<Metric, Int> = mapOf(
        Metric.CYCLES_LOGGED to cyclesLogged,
        Metric.ACTIVE_DAYS to activeDays().size,
        Metric.SECTIONS_VISITED to visitedSections().size,
        Metric.CUSTOMIZATIONS to customizations(),
        Metric.DAYS_SINCE_JOIN to ChronoUnit.DAYS.between(joinDate(), LocalDate.now()).toInt(),
    )

    /** Полное удаление данных прогресса и настроек. */
    fun clearAll() {
        map.clear()
        secure.delete()
    }
}
