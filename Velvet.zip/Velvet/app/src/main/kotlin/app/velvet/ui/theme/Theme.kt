package app.velvet.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Палитра «рассвет»: тёплые нейтрали + сливовый, шалфей и терракота. Красный не используется как «тревожный».
private val Plum = Color(0xFF6B3A5B)
private val Sage = Color(0xFF7F9C85)
private val Terracotta = Color(0xFFC27A5E)
private val Sand = Color(0xFFFAF4EC)
private val Ink = Color(0xFF2A2128)

private val LightColors = lightColorScheme(
    primary = Plum,
    onPrimary = Color.White,
    secondary = Sage,
    tertiary = Terracotta,
    background = Sand,
    onBackground = Ink,
    surface = Color(0xFFFFFBF6),
    onSurface = Ink,
    surfaceVariant = Color(0xFFF1E7DB),
    onSurfaceVariant = Color(0xFF5A4C55),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFE0B4D0),
    onPrimary = Color(0xFF3B1B31),
    secondary = Color(0xFFA9C4AE),
    tertiary = Color(0xFFE7A88C),
    background = Color(0xFF1C161B),
    onBackground = Color(0xFFF1E7EE),
    surface = Color(0xFF251E24),
    onSurface = Color(0xFFF1E7EE),
    surfaceVariant = Color(0xFF3A2F38),
    onSurfaceVariant = Color(0xFFD4C3CE),
)

@Composable
fun VelvetTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}
