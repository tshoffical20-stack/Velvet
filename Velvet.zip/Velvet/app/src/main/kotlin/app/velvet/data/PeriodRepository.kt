package app.velvet.data

import java.time.LocalDate

/** Локальное зашифрованное хранилище дат начала менструаций. */
class PeriodRepository(private val store: SecureStore) {

    fun load(): List<LocalDate> =
        store.read()
            ?.split(',')
            ?.mapNotNull { runCatching { LocalDate.parse(it.trim()) }.getOrNull() }
            ?.distinct()
            ?.sorted()
            .orEmpty()

    fun add(date: LocalDate): List<LocalDate> = save((load() + date).distinct().sorted())

    fun remove(date: LocalDate): List<LocalDate> = save(load() - date)

    fun clear() = store.delete()

    fun removeLast(): List<LocalDate> = save(load().dropLast(1))

    private fun save(dates: List<LocalDate>): List<LocalDate> {
        if (dates.isEmpty()) store.delete() else store.write(dates.joinToString(","))
        return dates
    }
}
