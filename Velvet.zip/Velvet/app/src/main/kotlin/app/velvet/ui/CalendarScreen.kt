package app.velvet.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.velvet.R
import app.velvet.UiState
import app.velvet.VelvetViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private fun fmt(date: LocalDate): String =
    date.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()))

@Composable
fun CalendarScreen(state: UiState, vm: VelvetViewModel) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Календарь", style = MaterialTheme.typography.headlineMedium)
        MonthHeader(state, vm)
        WeekdayRow()
        MonthGrid(state, vm)
        Legend()
        SelectedDayCard(state, vm)
        state.prediction?.let { PredictionCard(it) }
        if (state.flags.isNotEmpty()) DoctorFlagsCard(state.flags)
        if (state.prediction == null) Text(stringResource(R.string.empty_state), style = MaterialTheme.typography.bodyMedium)
        Text(
            stringResource(R.string.disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun MonthHeader(state: UiState, vm: VelvetViewModel) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = { vm.shiftMonth(-1) }) { Text("‹ Назад") }
        Text(
            state.month.format(DateTimeFormatter.ofPattern("LLLL yyyy", Locale.getDefault())),
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium,
        )
        TextButton(onClick = { vm.shiftMonth(1) }) { Text("Вперёд ›") }
    }
}

@Composable
private fun WeekdayRow() {
    Row(Modifier.fillMaxWidth()) {
        DayOfWeek.values().forEach { d ->
            Text(
                d.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MonthGrid(state: UiState, vm: VelvetViewModel) {
    val first = state.month.atDay(1)
    val offset = first.dayOfWeek.value - 1
    val length = state.month.lengthOfMonth()
    val rows = (offset + length + 6) / 7
    Column {
        repeat(rows) { row ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { col ->
                    val day = row * 7 + col - offset + 1
                    if (day in 1..length) {
                        DayCell(state, state.month.atDay(day)) { vm.select(it) }
                    } else {
                        Spacer(Modifier.weight(1f).aspectRatio(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.DayCell(state: UiState, date: LocalDate, onClick: (LocalDate) -> Unit) {
    val pred = state.prediction
    val isStart = date in state.starts
    val inPeriod = pred?.nextStartRange?.contains(date) == true
    val inOvulation = pred?.likelyOvulationWindow?.contains(date) == true
    val selected = date == state.selected
    val colors = MaterialTheme.colorScheme

    val (bg, fg) = when {
        isStart -> colors.primary to colors.onPrimary
        inPeriod -> colors.primaryContainer to colors.onPrimaryContainer
        inOvulation -> colors.tertiaryContainer to colors.onTertiaryContainer
        else -> androidx.compose.ui.graphics.Color.Transparent to colors.onSurface
    }
    val label = buildString {
        append(fmt(date))
        if (isStart) append(", отмечено начало менструации")
        else if (inPeriod) append(", возможный период менструации")
        else if (inOvulation) append(", возможное окно овуляции")
        if (date == state.today) append(", сегодня")
    }
    Box(
        Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(CircleShape).background(bg)
            .then(if (selected) Modifier.border(2.dp, colors.primary, CircleShape) else Modifier)
            .clickable { onClick(date) }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            date.dayOfMonth.toString(),
            color = fg,
            fontWeight = if (date == state.today) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun Legend() {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("● Отмеченное начало менструации", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        Text("● Возможный период следующей менструации", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
        Text("● Возможное окно овуляции (ориентировочно)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
    }
}

@Composable
private fun SelectedDayCard(state: UiState, vm: VelvetViewModel) {
    val sel = state.selected
    val isStart = sel in state.starts
    val future = sel.isAfter(state.today)
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(sel.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.getDefault())), style = MaterialTheme.typography.titleMedium)
            if (future) {
                Text("Отметить начало можно только за сегодняшний или прошедший день.", style = MaterialTheme.typography.bodyMedium)
            } else {
                Button(onClick = { vm.togglePeriodStart(sel) }) {
                    Text(if (isStart) "Снять отметку начала менструации" else "Отметить начало менструации")
                }
            }
        }
    }
}
