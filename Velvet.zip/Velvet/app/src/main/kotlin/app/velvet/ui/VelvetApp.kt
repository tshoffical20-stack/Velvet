package app.velvet.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import app.velvet.UiState
import app.velvet.VelvetViewModel

private data class Tab(val route: String, val label: String, val glyph: String)

private val tabs = listOf(
    Tab("calendar", "Календарь", "◔"),
    Tab("progress", "Прогресс", "★"),
    Tab("settings", "Настройки", "⚙"),
)

@Composable
fun VelvetApp(state: UiState, vm: VelvetViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "calendar"
    LaunchedEffect(route) { vm.visitSection(route) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = route == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Text(tab.glyph) },
                        label = { Text(tab.label) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = "calendar", modifier = Modifier.padding(padding)) {
            composable("calendar") { CalendarScreen(state, vm) }
            composable("progress") { ProgressScreen(state) }
            composable("settings") { SettingsScreen(state, vm) }
        }
    }
}
