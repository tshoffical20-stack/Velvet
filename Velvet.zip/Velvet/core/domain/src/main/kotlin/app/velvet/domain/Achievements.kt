package app.velvet.domain

/** Метрики — только счётчики полезных действий. Ни одна не связана с сексуальной активностью, весом или «успехом» цикла. */
enum class Metric {
    DIARY_ENTRIES, ACTIVE_DAYS, MOOD_ENTRIES, SELFCARE_ACTIONS, ARTICLES_READ, QUIZZES_DONE,
    SECTIONS_VISITED, REPORTS_VIEWED, GOALS_COMPLETED, CYCLES_LOGGED, DAYS_SINCE_JOIN,
    COLLECTION_ITEMS, CUSTOMIZATIONS,
}

enum class AchievementCategory(val title: String) {
    FIRST_STEPS("Первые шаги"),
    REGULARITY("Регулярность"),
    SELF_KNOWLEDGE("Самопознание"),
    SELF_CARE("Забота о себе"),
    EDUCATION("Образование"),
    EXPLORER("Исследователь"),
    ANALYTICS("Аналитика"),
    PERSONAL_GOALS("Личные цели"),
    LONG_TERM("Долгосрочные достижения"),
    COLLECTIONS("Особые коллекции"),
}

data class Achievement(
    val id: String,
    val category: AchievementCategory,
    val title: String,
    val metric: Metric,
    val threshold: Int,
) {
    fun current(stats: Map<Metric, Int>): Int = (stats[metric] ?: 0).coerceAtMost(threshold)
    fun isUnlocked(stats: Map<Metric, Int>): Boolean = (stats[metric] ?: 0) >= threshold
}

object AchievementCatalog {
    private fun r(title: String, metric: Metric, threshold: Int) = Triple(title, metric, threshold)

    private fun cat(category: AchievementCategory, rows: List<Triple<String, Metric, Int>>): List<Achievement> =
        rows.mapIndexed { i, (title, metric, th) ->
            Achievement("${category.name.lowercase()}_${i + 1}", category, title, metric, th)
        }

    val all: List<Achievement> = buildList {
        addAll(cat(AchievementCategory.FIRST_STEPS, listOf(
            r("Первая запись", Metric.DIARY_ENTRIES, 1),
            r("Знакомство с календарём", Metric.CYCLES_LOGGED, 1),
            r("Первый взгляд на график", Metric.REPORTS_VIEWED, 1),
            r("Первая статья", Metric.ARTICLES_READ, 1),
            r("Первая цель", Metric.GOALS_COMPLETED, 1),
            r("Заглянула в разделы", Metric.SECTIONS_VISITED, 3),
            r("Первое настроение", Metric.MOOD_ENTRIES, 1),
            r("Забота началась", Metric.SELFCARE_ACTIONS, 1),
            r("Первое задание", Metric.QUIZZES_DONE, 1),
            r("Свой внешний вид", Metric.CUSTOMIZATIONS, 1),
            r("Первая находка", Metric.COLLECTION_ITEMS, 1),
        )))
        addAll(cat(AchievementCategory.REGULARITY, listOf(
            r("Два дня", Metric.ACTIVE_DAYS, 2),
            r("Три дня", Metric.ACTIVE_DAYS, 3),
            r("Пять дней", Metric.ACTIVE_DAYS, 5),
            r("Неделя рядом", Metric.ACTIVE_DAYS, 7),
            r("Десять дней", Metric.ACTIVE_DAYS, 10),
            r("Две недели", Metric.ACTIVE_DAYS, 14),
            r("Три недели", Metric.ACTIVE_DAYS, 21),
            r("Месяц присутствия", Metric.ACTIVE_DAYS, 30),
            r("Полтора месяца", Metric.ACTIVE_DAYS, 45),
            r("Два месяца", Metric.ACTIVE_DAYS, 60),
            r("Квартал", Metric.ACTIVE_DAYS, 90),
        )))
        addAll(cat(AchievementCategory.SELF_KNOWLEDGE, listOf(
            r("Прислушиваюсь", Metric.MOOD_ENTRIES, 5),
            r("Эмоции на виду", Metric.MOOD_ENTRIES, 10),
            r("Чувствую глубже", Metric.MOOD_ENTRIES, 25),
            r("Карта настроений", Metric.MOOD_ENTRIES, 50),
            r("Сто оттенков", Metric.MOOD_ENTRIES, 100),
            r("Эмоциональный навигатор", Metric.MOOD_ENTRIES, 200),
            r("Наблюдательница", Metric.DIARY_ENTRIES, 10),
            r("Внимательный дневник", Metric.DIARY_ENTRIES, 25),
            r("Дневник на ладони", Metric.DIARY_ENTRIES, 50),
            r("Летопись дня", Metric.DIARY_ENTRIES, 100),
            r("Книга о себе", Metric.DIARY_ENTRIES, 250),
        )))
        addAll(cat(AchievementCategory.SELF_CARE, listOf(
            r("Три заботы", Metric.SELFCARE_ACTIONS, 3),
            r("Неделя заботы", Metric.SELFCARE_ACTIONS, 7),
            r("Пятнадцать забот", Metric.SELFCARE_ACTIONS, 15),
            r("Месяц заботы", Metric.SELFCARE_ACTIONS, 30),
            r("Полсотни", Metric.SELFCARE_ACTIONS, 50),
            r("Бережный ритм", Metric.SELFCARE_ACTIONS, 75),
            r("Сотня забот", Metric.SELFCARE_ACTIONS, 100),
            r("Тёплый уют", Metric.SELFCARE_ACTIONS, 150),
            r("Двести мгновений", Metric.SELFCARE_ACTIONS, 200),
            r("Опора себе", Metric.SELFCARE_ACTIONS, 300),
            r("Пятьсот шагов к себе", Metric.SELFCARE_ACTIONS, 500),
        )))
        addAll(cat(AchievementCategory.EDUCATION, listOf(
            r("Любопытство", Metric.ARTICLES_READ, 3),
            r("Пять открытий", Metric.ARTICLES_READ, 5),
            r("Десять статей", Metric.ARTICLES_READ, 10),
            r("Библиотека", Metric.ARTICLES_READ, 20),
            r("Знаток тела", Metric.ARTICLES_READ, 35),
            r("Эрудитка", Metric.ARTICLES_READ, 50),
            r("Три проверки", Metric.QUIZZES_DONE, 3),
            r("Мифы разоблачены", Metric.QUIZZES_DONE, 5),
            r("Десять заданий", Metric.QUIZZES_DONE, 10),
            r("Умница", Metric.QUIZZES_DONE, 20),
            r("Мастер знаний", Metric.QUIZZES_DONE, 30),
        )))
        addAll(cat(AchievementCategory.EXPLORER, listOf(
            r("Путешественница", Metric.SECTIONS_VISITED, 5),
            r("Исследовательница", Metric.SECTIONS_VISITED, 8),
            r("Картографка", Metric.SECTIONS_VISITED, 10),
            r("Всё видела", Metric.SECTIONS_VISITED, 12),
            r("Не осталось тайн", Metric.SECTIONS_VISITED, 15),
            r("Мастер настроек", Metric.CUSTOMIZATIONS, 3),
            r("Свой стиль", Metric.CUSTOMIZATIONS, 5),
            r("Дизайнер дня", Metric.CUSTOMIZATIONS, 10),
            r("Тонкая настройка", Metric.CUSTOMIZATIONS, 15),
            r("Идеальный вид", Metric.CUSTOMIZATIONS, 20),
            r("Моё пространство", Metric.CUSTOMIZATIONS, 30),
        )))
        addAll(cat(AchievementCategory.ANALYTICS, listOf(
            r("Второй взгляд", Metric.REPORTS_VIEWED, 2),
            r("Три отчёта", Metric.REPORTS_VIEWED, 3),
            r("Пять срезов", Metric.REPORTS_VIEWED, 5),
            r("Десять графиков", Metric.REPORTS_VIEWED, 10),
            r("Аналитик-новичок", Metric.REPORTS_VIEWED, 15),
            r("Сравниваю циклы", Metric.REPORTS_VIEWED, 25),
            r("Ищу закономерности", Metric.REPORTS_VIEWED, 40),
            r("Детектив данных", Metric.REPORTS_VIEWED, 60),
            r("Сто взглядов", Metric.REPORTS_VIEWED, 100),
            r("Знаток данных", Metric.REPORTS_VIEWED, 150),
            r("Мастер аналитики", Metric.REPORTS_VIEWED, 200),
        )))
        addAll(cat(AchievementCategory.PERSONAL_GOALS, listOf(
            r("Две цели", Metric.GOALS_COMPLETED, 2),
            r("Три цели", Metric.GOALS_COMPLETED, 3),
            r("Пять целей", Metric.GOALS_COMPLETED, 5),
            r("Десять целей", Metric.GOALS_COMPLETED, 10),
            r("Пятнадцать", Metric.GOALS_COMPLETED, 15),
            r("Четверть сотни", Metric.GOALS_COMPLETED, 25),
            r("Сорок шагов", Metric.GOALS_COMPLETED, 40),
            r("Шестьдесят побед", Metric.GOALS_COMPLETED, 60),
            r("Восемьдесят", Metric.GOALS_COMPLETED, 80),
            r("Сотня целей", Metric.GOALS_COMPLETED, 100),
            r("Мастер привычек", Metric.GOALS_COMPLETED, 150),
        )))
        addAll(cat(AchievementCategory.LONG_TERM, listOf(
            r("Месяц вместе", Metric.DAYS_SINCE_JOIN, 30),
            r("Квартал вместе", Metric.DAYS_SINCE_JOIN, 90),
            r("Полгода вместе", Metric.DAYS_SINCE_JOIN, 180),
            r("Год с Velvet", Metric.DAYS_SINCE_JOIN, 365),
            r("Полтора года", Metric.DAYS_SINCE_JOIN, 540),
            r("Два года", Metric.DAYS_SINCE_JOIN, 730),
            r("Три цикла", Metric.CYCLES_LOGGED, 3),
            r("Полгода циклов", Metric.CYCLES_LOGGED, 6),
            r("Год циклов", Metric.CYCLES_LOGGED, 12),
            r("Два года циклов", Metric.CYCLES_LOGGED, 24),
            r("Три года циклов", Metric.CYCLES_LOGGED, 36),
        )))
        addAll(cat(AchievementCategory.COLLECTIONS, listOf(
            r("Пара находок", Metric.COLLECTION_ITEMS, 2),
            r("Тройка", Metric.COLLECTION_ITEMS, 3),
            r("Пять сокровищ", Metric.COLLECTION_ITEMS, 5),
            r("Восемь предметов", Metric.COLLECTION_ITEMS, 8),
            r("Дюжина", Metric.COLLECTION_ITEMS, 12),
            r("Шестнадцать", Metric.COLLECTION_ITEMS, 16),
            r("Двадцатка", Metric.COLLECTION_ITEMS, 20),
            r("Четверть сотни находок", Metric.COLLECTION_ITEMS, 25),
            r("Тридцать", Metric.COLLECTION_ITEMS, 30),
            r("Сорок", Metric.COLLECTION_ITEMS, 40),
            r("Полсотни находок", Metric.COLLECTION_ITEMS, 50),
        )))
    }

    fun unlocked(stats: Map<Metric, Int>): List<Achievement> = all.filter { it.isUnlocked(stats) }
}
