package app.velvet.domain.cycle

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Ситуации, при которых разумно обратиться к врачу. Это не диагноз. */
enum class DoctorFlag {
    CYCLE_SHORTER_THAN_21,
    CYCLE_LONGER_THAN_35,
    PERIOD_LONGER_THAN_7_DAYS,
    NO_PERIOD_FOR_90_DAYS,
}

data class PeriodRecord(val start: LocalDate, val end: LocalDate? = null)

object HealthFlags {
    fun evaluate(periods: List<PeriodRecord>, today: LocalDate): Set<DoctorFlag> {
        val sorted = periods.sortedBy { it.start }
        val flags = linkedSetOf<DoctorFlag>()

        // Смотрим последний цикл — только по фактически завершённым данным.
        if (sorted.size >= 2) {
            val lastLen = ChronoUnit.DAYS.between(sorted[sorted.size - 2].start, sorted.last().start).toInt()
            if (lastLen < 21) flags += DoctorFlag.CYCLE_SHORTER_THAN_21
            if (lastLen > 35) flags += DoctorFlag.CYCLE_LONGER_THAN_35
        }
        sorted.lastOrNull()?.let { p ->
            val end = p.end
            if (end != null && ChronoUnit.DAYS.between(p.start, end) + 1 > 7) {
                flags += DoctorFlag.PERIOD_LONGER_THAN_7_DAYS
            }
            if (ChronoUnit.DAYS.between(p.start, today) >= 90) {
                flags += DoctorFlag.NO_PERIOD_FOR_90_DAYS
            }
        }
        return flags
    }
}
