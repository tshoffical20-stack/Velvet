package app.velvet.domain.cycle

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Насколько можно доверять прогнозу. */
enum class Confidence { INSUFFICIENT_DATA, LOW, MODERATE, HIGH }

/** Диапазон дат (включительно). Прогноз всегда диапазон, а не одна «точная» дата. */
data class DateRange(val start: LocalDate, val end: LocalDate) {
    init {
        require(!end.isBefore(start)) { "end < start" }
    }

    operator fun contains(date: LocalDate): Boolean = !date.isBefore(start) && !date.isAfter(end)
    val lengthDays: Int get() = ChronoUnit.DAYS.between(start, end).toInt() + 1
}

data class CyclePrediction(
    /** Наиболее вероятное начало следующей менструации. */
    val expectedNextStart: LocalDate,
    /** Диапазон, в который начало попадает с приблизительно 80% вероятностью (при нормальном распределении). */
    val nextStartRange: DateRange,
    /** Вероятное окно овуляции. Не точная дата и не гарантия. */
    val likelyOvulationWindow: DateRange,
    /** Окно повышенной вероятности зачатия. НЕ является методом контрацепции. */
    val fertileWindow: DateRange,
    val averageCycleLengthDays: Double,
    val cycleLengthStdDevDays: Double,
    val cyclesUsed: Int,
    val confidence: Confidence,
)

/**
 * Прогноз по индивидуальной истории: взвешенное (экспоненциальное) среднее длин циклов,
 * новейшие циклы весят больше. Неопределённость отражается шириной диапазонов.
 *
 * Важно: результат не предназначен для контрацепции.
 */
class CyclePredictor(
    private val decay: Double = 0.75,
    private val defaultCycleLengthDays: Int = 28,
    private val lutealPhaseDays: Int = 14,
    private val minPlausibleCycleDays: Int = 15,
    private val maxPlausibleCycleDays: Int = 90,
) {
    init {
        require(decay in 0.1..1.0)
        require(lutealPhaseDays in 8..18)
    }

    /**
     * @param periodStarts даты начала менструаций (любой порядок, дубликаты допустимы).
     * @return null, если нет ни одной отмеченной менструации.
     */
    fun predict(periodStarts: Collection<LocalDate>): CyclePrediction? {
        val starts = periodStarts.distinct().sorted()
        if (starts.isEmpty()) return null

        val lengths = starts.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }
            .filter { it in minPlausibleCycleDays..maxPlausibleCycleDays }

        val last = starts.last()
        val stats = weightedStats(lengths)
        val mean = stats?.first ?: defaultCycleLengthDays.toDouble()
        val sd = stats?.second ?: 0.0

        val confidence = confidenceFor(lengths.size, sd)

        // Полуширина диапазона: при малом объёме данных — шире.
        val halfWidth = when (confidence) {
            Confidence.INSUFFICIENT_DATA -> 7
            else -> max(2, (1.28 * max(sd, 1.0)).roundToInt() + if (confidence == Confidence.LOW) 1 else 0)
        }

        val expectedStart = last.plusDays(mean.roundToInt().toLong())
        val nextRange = DateRange(expectedStart.minusDays(halfWidth.toLong()), expectedStart.plusDays(halfWidth.toLong()))

        val ovulation = expectedStart.minusDays(lutealPhaseDays.toLong())
        val ovHalf = min(halfWidth, 6).coerceAtLeast(2)
        val ovulationWindow = DateRange(ovulation.minusDays(ovHalf.toLong()), ovulation.plusDays(ovHalf.toLong()))
        // Сперматозоиды живут до ~5 дней, яйцеклетка ~1 день.
        val fertile = DateRange(ovulationWindow.start.minusDays(5), ovulationWindow.end.plusDays(1))

        return CyclePrediction(
            expectedNextStart = expectedStart,
            nextStartRange = nextRange,
            likelyOvulationWindow = ovulationWindow,
            fertileWindow = fertile,
            averageCycleLengthDays = mean,
            cycleLengthStdDevDays = sd,
            cyclesUsed = lengths.size,
            confidence = confidence,
        )
    }

    private fun confidenceFor(n: Int, sd: Double): Confidence = when {
        n == 0 -> Confidence.INSUFFICIENT_DATA
        n < 3 -> Confidence.LOW
        sd > 5.0 -> Confidence.LOW
        n >= 6 && sd <= 2.5 -> Confidence.HIGH
        else -> Confidence.MODERATE
    }

    /** Возвращает (взвешенное среднее, взвешенное стандартное отклонение) либо null при пустом списке. */
    private fun weightedStats(lengths: List<Int>): Pair<Double, Double>? {
        if (lengths.isEmpty()) return null
        val n = lengths.size
        // Индекс n-1 — самый новый цикл.
        val weights = DoubleArray(n) { i -> Math.pow(decay, (n - 1 - i).toDouble()) }
        val wSum = weights.sum()
        val mean = lengths.indices.sumOf { lengths[it] * weights[it] } / wSum
        val variance = lengths.indices.sumOf { weights[it] * (lengths[it] - mean) * (lengths[it] - mean) } / wSum
        return mean to sqrt(variance)
    }
}
