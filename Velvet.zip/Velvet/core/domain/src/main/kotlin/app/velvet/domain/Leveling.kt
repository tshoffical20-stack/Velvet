package app.velvet.domain

import kotlin.math.pow
import kotlin.math.roundToLong

data class LevelProgress(val level: Int, val xpIntoLevel: Long, val xpForNextLevel: Long) {
    val fraction: Float get() = if (xpForNextLevel == 0L) 0f else xpIntoLevel.toFloat() / xpForNextLevel
}

/**
 * XP только растёт: пропуски дней, нерегулярный цикл или плохое самочувствие никогда его не уменьшают.
 * Шаг с уровня n на n+1 равен round(100 * n^1.4).
 */
object Leveling {
    fun xpForStep(level: Int): Long = (100.0 * level.toDouble().pow(1.4)).roundToLong()

    fun totalXpToReach(level: Int): Long {
        var sum = 0L
        for (k in 1 until level) sum += xpForStep(k)
        return sum
    }

    fun levelFor(totalXp: Long): Int {
        val xp = totalXp.coerceAtLeast(0)
        var level = 1
        while (xp >= totalXpToReach(level + 1)) level++
        return level
    }

    fun progress(totalXp: Long): LevelProgress {
        val xp = totalXp.coerceAtLeast(0)
        val level = levelFor(xp)
        return LevelProgress(level, xp - totalXpToReach(level), xpForStep(level))
    }
}
