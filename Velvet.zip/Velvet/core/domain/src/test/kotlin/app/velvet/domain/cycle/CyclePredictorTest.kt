package app.velvet.domain.cycle

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CyclePredictorTest {
    private val predictor = CyclePredictor()
    private val d0 = LocalDate.of(2026, 1, 1)

    @Test
    fun `no data returns null`() {
        assertNull(predictor.predict(emptyList()))
    }

    @Test
    fun `single period uses default length and wide range`() {
        val p = predictor.predict(listOf(d0))!!
        assertEquals(Confidence.INSUFFICIENT_DATA, p.confidence)
        assertEquals(d0.plusDays(28), p.expectedNextStart)
        assertEquals(15, p.nextStartRange.lengthDays)
    }

    @Test
    fun `regular 28 day cycles give high confidence and tight range`() {
        val starts = (0..6).map { d0.plusDays(28L * it) }
        val p = predictor.predict(starts)!!
        assertEquals(Confidence.HIGH, p.confidence)
        assertEquals(starts.last().plusDays(28), p.expectedNextStart)
        assertTrue(p.nextStartRange.lengthDays <= 7)
        assertTrue(p.expectedNextStart in p.nextStartRange)
    }

    @Test
    fun `recent cycles weigh more`() {
        val starts = mutableListOf(d0)
        repeat(4) { starts += starts.last().plusDays(30) }
        repeat(4) { starts += starts.last().plusDays(26) }
        val p = predictor.predict(starts)!!
        assertTrue(p.averageCycleLengthDays < 28.0)
    }

    @Test
    fun `ovulation window precedes next period by about luteal phase`() {
        val starts = (0..4).map { d0.plusDays(28L * it) }
        val p = predictor.predict(starts)!!
        val center = p.expectedNextStart.minusDays(14)
        assertTrue(center in p.likelyOvulationWindow)
        assertTrue(p.fertileWindow.start.isBefore(p.likelyOvulationWindow.start))
    }

    @Test
    fun `irregular cycles lower confidence and widen range`() {
        val lengths = listOf(24, 38, 27, 41, 25)
        val starts = mutableListOf(d0)
        lengths.forEach { starts += starts.last().plusDays(it.toLong()) }
        val p = predictor.predict(starts)!!
        assertEquals(Confidence.LOW, p.confidence)
        assertTrue(p.nextStartRange.lengthDays >= 9)
    }

    @Test
    fun `implausible gaps are ignored`() {
        val p = predictor.predict(listOf(d0, d0.plusDays(5), d0.plusDays(33)))!!
        assertEquals(1, p.cyclesUsed)
    }

    @Test
    fun `duplicates and unsorted input are handled`() {
        val a = predictor.predict(listOf(d0.plusDays(28), d0, d0, d0.plusDays(56)))!!
        val b = predictor.predict(listOf(d0, d0.plusDays(28), d0.plusDays(56)))!!
        assertEquals(b.expectedNextStart, a.expectedNextStart)
    }
}
