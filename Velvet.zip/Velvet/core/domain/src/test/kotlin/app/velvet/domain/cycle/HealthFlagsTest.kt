package app.velvet.domain.cycle

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthFlagsTest {
    private val d0 = LocalDate.of(2026, 1, 1)

    @Test
    fun `normal cycle has no flags`() {
        val periods = listOf(PeriodRecord(d0, d0.plusDays(4)), PeriodRecord(d0.plusDays(28), d0.plusDays(32)))
        assertTrue(HealthFlags.evaluate(periods, d0.plusDays(40)).isEmpty())
    }

    @Test
    fun `short and long cycles are flagged`() {
        val short = listOf(PeriodRecord(d0), PeriodRecord(d0.plusDays(19)))
        assertEquals(setOf(DoctorFlag.CYCLE_SHORTER_THAN_21), HealthFlags.evaluate(short, d0.plusDays(25)))
        val long = listOf(PeriodRecord(d0), PeriodRecord(d0.plusDays(40)))
        assertEquals(setOf(DoctorFlag.CYCLE_LONGER_THAN_35), HealthFlags.evaluate(long, d0.plusDays(45)))
    }

    @Test
    fun `long period and missing period are flagged`() {
        val periods = listOf(PeriodRecord(d0, d0.plusDays(8)))
        val flags = HealthFlags.evaluate(periods, d0.plusDays(95))
        assertTrue(DoctorFlag.PERIOD_LONGER_THAN_7_DAYS in flags)
        assertTrue(DoctorFlag.NO_PERIOD_FOR_90_DAYS in flags)
    }
}
