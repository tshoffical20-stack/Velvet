package app.velvet.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GamificationTest {
    @Test fun levelingIsMonotonicAndNeverNegative() {
        assertEquals(1, Leveling.levelFor(-50))
        assertEquals(100L, Leveling.xpForStep(1))
        assertEquals(100L, Leveling.totalXpToReach(2))
        var prev = 0L
        for (l in 1..50) { val t = Leveling.totalXpToReach(l); assertTrue(t >= prev); prev = t }
        val p = Leveling.progress(100)
        assertEquals(2, p.level)
        assertEquals(0L, p.xpIntoLevel)
        assertTrue(p.fraction in 0f..1f)
    }

    @Test fun catalogHasAtLeast100UniqueAchievementsInAllTenCategories() {
        val all = AchievementCatalog.all
        assertTrue(all.size >= 100)
        assertEquals(all.size, all.map { it.id }.toSet().size)
        assertEquals(all.size, all.map { it.title }.toSet().size)
        assertEquals(10, all.map { it.category }.toSet().size)
        AchievementCategory.values().forEach { c -> assertTrue(all.count { it.category == c } >= 10) }
    }

    @Test fun achievementsUnlockFromRealStatsOnly() {
        assertTrue(AchievementCatalog.unlocked(emptyMap()).isEmpty())
        val u = AchievementCatalog.unlocked(mapOf(Metric.DIARY_ENTRIES to 1))
        assertEquals(listOf("Первая запись"), u.map { it.title })
    }
}
